# HackberryPi 2019

This is the repo where the 'Pi Poppers' can stick awesome code!

## Components
* [SparkFun Soil Moisture Sensor](https://www.sparkfun.com/products/13322)
* [MCP3008 ADC](https://www.adafruit.com/product/856)
* [DHT11](https://www.adafruit.com/product/386)
* some plants
* a plant holder

## Resources
[ADC](https://learn.adafruit.com/reading-a-analog-in-and-controlling-audio-volume-with-the-raspberry-pi "ADC Tutorial")

[Temp](https://learn.adafruit.com/dht/overview "Temp Sensor Tutorial")
